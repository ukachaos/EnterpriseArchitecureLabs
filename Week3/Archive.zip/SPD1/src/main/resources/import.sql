insert into Student values(12345, 'Frank', 'Brown');
insert into Course values(1101, 'Java', 'A');
insert into Course values(1102, 'Math', 'B+');
insert into Student_Course values(12345, 1101);
insert into Student_Course values(12345, 1102);